import React from 'react'
import { Route, Routes } from 'react-router-dom'
import AllRoutes from './Routes/Routes'


function App() {
  return (
    <>
      
      <AllRoutes/>
        
    </>
  )
}

export default App