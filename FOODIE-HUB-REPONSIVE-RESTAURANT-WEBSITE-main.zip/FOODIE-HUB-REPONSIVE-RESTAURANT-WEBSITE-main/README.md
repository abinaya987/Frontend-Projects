# FOODIE-HUB-REPONSIVE-RESTAURANT-WEBSITE
 Created a restaurant website using HTML, CSS, Java Script and jquery. Designed pages like Home,Contact, Login, and Food Details. MMode the weebsite mobile-friendly with easy navigation and ordering buttons. 
